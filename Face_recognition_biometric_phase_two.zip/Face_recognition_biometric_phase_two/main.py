from flask import Flask, request, jsonify, render_template

# Importing functions related to face recognition
from face_recognition_util import (
    capture_image as capture_face_image, # Capture an image for face recognition
    change_bgr_rgb as face_change_bgr_rgb, # Convert the image color space from BGR to RGB
    detect_faces, # Detect faces in an image
    get_face_embeddings, # Extract face embeddings for recognition
    store_face_embedding, # Store face embeddings
    load_face_embeddings,  # Load stored face embeddings
    calc_distance # Calculate distance between face embeddings for comparison
)

# Importing functions related to iris recognition
from iris_recognition_util import (
    capture_image as capture_iris_image, # Capture an image for iris recognition
    change_bgr_rgb as iris_change_bgr_rgb, # Convert the image color space from BGR to RGB
    extract_iris_features,  # Extract iris features for recognition
    store_features, # Store extracted iris features
    load_features,   # Load stored iris features
    verify_iris_features as verify_iris_identity # Verify iris identity by comparing features
)

# Importing functions related to lip recognition
from lips_recognition_util import (
    capture_image as capture_lip_image,  # Capture an image for lip recognition
    change_bgr_rgb as lip_change_bgr_rgb, # Convert the image color space from BGR to RGB
    extract_lip_features, # Extract lip features for recognition
    store_lip_features, # Store extracted lip features
    load_lip_features,  # Load stored lip features
    verify_lip_identity  # Verify lip identity by comparing features
)

app = Flask(__name__) # Create an instance of the Flask class for your web application

@app.route('/') # Define a root url for the web application
def index(): # index function will be called whenever the user access the root url
    return render_template('index.html') # index.html page will be rendered and returned


@app.route('/register', methods=['GET', 'POST']) # Define a root url for the for '/register' , that supports 'GET' and 'POST' requests
def register(): # this method will help capture the users face , iris and lip features during initial registration
    if request.method == 'POST': #check if the request is 'POST' indicating form submission
        name = request.form['name'] #extract the name of the user from the submitted data
        errors = [] #initialize an empty list to collect error messages
        try:
            #face recognition section
            # Capture an image from the webcam using the logic of capture_face_image function
            face_frame = capture_face_image()
            #convert the captured image from BGR to RGB using the mentioned function
            face_rgb_img = face_change_bgr_rgb(face_frame)
            #detect the faces from thr captured image using the detect face function
            face_loc = detect_faces(face_rgb_img)
            #if face is detected in the image extract and store the face embeddings along with the name
            if face_loc and len(face_loc) > 0:
                face_embeddings = get_face_embeddings(face_rgb_img, face_loc)
                store_face_embedding(name, face_embeddings[0])
            else:
                #if no face detected , show an error message
                errors.append("Face not detected")

            # Iris recognition section
            # Capture an image from the Webcam using the caoture_iris_image function for iris detection
            iris_frame = capture_iris_image()
            #convert the captured image from BGR to RGB using the mentioned function
            iris_rgb_img = iris_change_bgr_rgb(iris_frame)
            # Extract features from the iris image.
            iris_features = extract_iris_features(iris_rgb_img)
            #if iris features are detected in the image ,extract and store the iris features along with the name
            if iris_features is not None and len(iris_features) > 0:
                #store the iris features and user name 
                store_features(name, iris_features)
            else:
                #if no iris features detected, show an error message
                errors.append("Iris not detected")

            # Capture and store lip features
            # Lip recognition section
            # Capture an image from the Webcam using the caoture_lip_image function for lip detection
            lip_frame = capture_lip_image()
            #convert the captured image from BGR to RGB using the mentioned function
            lip_rgb_img = lip_change_bgr_rgb(lip_frame)
            # Extract features from the lip image.
            lip_features, lip_error = extract_lip_features(lip_rgb_img)
            #if lip features are None ,store the lip features not detected
            if lip_error or lip_features is None or len(lip_features) == 0:
                errors.append("Lips not detected")
            else:
                #else store the lip features along with the user name
                store_lip_features(name, lip_features)

            #If there are any errors , a json response with a registration failure message will be displayed
            if errors:
                return jsonify({"message": "Registration failed: " + ", ".join(errors)}), 400
            
            #otherwise , a json response with a registration success message will be displayed
            return jsonify({"message": "Registration successful"}), 200
        except Exception as e:
            #in case of an exception , a json response with an error message is shown
            return jsonify({"message": str(e)}), 500
    #if the request is GET ,then render the registration for the html page
    return render_template('register.html')

@app.route('/verify', methods=['GET', 'POST'])  # Define a root url for the for '/verification' , that supports 'GET' and 'POST' requests
def verify():#this function will help to verify the current user's itentity with the regiistered user's identity
    if request.method == 'POST': #check if the request is 'POST' indicating form submission
        try:
             # Initialize verification flags for face, iris, and lips.
            face_verified = False
            iris_verified = False
            lip_verified = False
            min_distance = float('inf') #initialize the minimum distance for face matching 
            matched_name = "Unknown" #initialize the matched_name 
            errors = [] # initialize a empty list for error

            #face recognition section
            # Capture the current image from the webcam using the logic of capture_face_image function
            face_frame = capture_face_image()
            #convert the captured image from BGR to RGB using the mentioned function
            face_rgb_img = face_change_bgr_rgb(face_frame)
            #detect the faces from thr captured image using the detect face function
            face_loc = detect_faces(face_rgb_img)
            #if face is detected in the image extract and store the face embeddings along with the name
            if face_loc and len(face_loc) > 0:
                face_embeddings = get_face_embeddings(face_rgb_img, face_loc)
                known_face_names, known_face_embeddings = load_face_embeddings()
                
                # Calculate the distance between the captured face embedding and each stored embedding.
                for known_name, known_embedding in zip(known_face_names, known_face_embeddings):
                    distance = calc_distance(face_embeddings[0], known_embedding)
                    if distance < min_distance:
                        min_distance = distance
                        matched_name = known_name
                
                
                # Set the face_verified flag if a match is found
                
                face_verified = (matched_name != "Unknown")
            else:

                 # If no face is detected, add an error message.
                errors.append("Face not detected")

            # Iris recognition section 
            iris_frame = capture_iris_image()
            # Capture a new image from the Webcam using the capture_iris_image function for iris detection
            iris_rgb_img = iris_change_bgr_rgb(iris_frame)
            # Extract features from the iris image.
            new_iris_features = extract_iris_features(iris_rgb_img)
            #if iris features are detected in the new image ,compare with stored data.
            if new_iris_features is not None and len(new_iris_features) > 0:
                stored_names, stored_iris_encodings = load_features()
                for iris_feature in new_iris_features:
                    iris_match_name = verify_iris_identity(iris_feature, stored_names, stored_iris_encodings)
                    if iris_match_name == matched_name:
                        iris_verified = True
                        break
            else:
                # If no iris features are detected, add an error message.
                errors.append("Iris not detected")

            # Lips recognition section
            #capture a new image of the lips for verification
            lip_frame = capture_lip_image()
            #convert the new lip image from BGR to RGB
            lip_rgb_img = lip_change_bgr_rgb(lip_frame)
            # Extract features from the lip image.
            new_lip_features, lip_error = extract_lip_features(lip_rgb_img)

            # If the new lip features are successfully extracted, compare with stored data.
            if lip_error:
                errors.append("Lips not detected")
            elif new_lip_features is not None and len(new_lip_features) > 0:
                stored_lip_names, stored_lip_encodings = load_lip_features()
                for lip_feature in new_lip_features:
                    lip_match_name = verify_lip_identity(lip_feature, stored_lip_names, stored_lip_encodings)
                    if lip_match_name == matched_name:
                        lip_verified = True
                        break
            else:
                # If no lip features are detected, add an error message.
                errors.append("Lips not detected")

            # Generate the response based on the verification results
            if face_verified and iris_verified and lip_verified:
                response = {"name": matched_name, "distance": min_distance, "status": "Verified"}
            else:
                error_message = "User not verified: " + ", ".join(errors) if errors else "Unknown user or incomplete verification"
                response = {"name": "Unknown", "status": error_message}
            
            # Return the response as a JSON object.
            return jsonify(response), 200
        except Exception as e:

             # If an exception occurs, return a JSON response with the error message.
            return jsonify({"message": str(e)}), 500
    #if the request is GET ,then render the registration for the html page
    return render_template('verify.html')

if __name__ == '__main__': # check if the script can be run directly
    app.run(debug=True) # run the flask application 
