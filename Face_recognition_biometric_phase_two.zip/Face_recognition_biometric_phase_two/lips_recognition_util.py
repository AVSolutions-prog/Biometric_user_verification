# import libraries
import cv2
import numpy as np
import sqlite3
import face_recognition


# database declaration and image size configuration
db_name = 'lip_recognition.db' #initialize a database and store it inside a variable
lip_size = (50, 25)  ##mention a iris image size to which the captured image will be resized


#capture image
def capture_image():
    video_capture = cv2.VideoCapture(0) #Opens the webcame
    ret, frame = video_capture.read()#captures a single frame of image from webcam
    video_capture.release() #release the webcam
    return frame #returns the captured image

#convert BGR to RGB
def change_bgr_rgb(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB) # convert the image from BGR to RGB and return that

def detect_hands_covering_lips(lip_region):# this function takes the input parameter as the lip region 
    hsv_img = cv2.cvtColor(lip_region, cv2.COLOR_RGB2HSV) #the lip region colour is converted from RGB to HSV , as it helps to separate the lip area from the brightness
    lower_lip_hsv = np.array([0, 50, 20]) # define the lower bound or darkest of the lip colour
    upper_lip_hsv = np.array([30, 255, 255]) # define the upper bound or the brightest of the lip colour
    mask = cv2.inRange(hsv_img, lower_lip_hsv, upper_lip_hsv)#taking the hsv_image and forming a mask of lip region using the upper and lower bound of lip colour
    lip_pixels = cv2.countNonZero(mask)#it then takes the mask created and count the white pixels that contain the lip colour and store them
    total_pixels = lip_region.shape[0] * lip_region.shape[1] # multiplying all the pixels in the row and column to get the total number of pixels in the lip region

    # flag statement to check if lips are covered by hands 
    if lip_pixels < total_pixels * 0.3:  # check if number of pixels in the lip_pixel is less than 30% of total_pixel
        return True # then lip is not properly captured
    return False # else lips properly detected

def extract_lip_features(rgb_image):
    face_landmarks_list = face_recognition.face_landmarks(rgb_image) # face_recognition library is used to extract the facial landmarks in the image
    lip_features = [] # initialize empty list to store the lip features
    lip_error = False  # Flag to indicate if lips were not properly detected

    for face_landmarks in face_landmarks_list: # loop over all the face landmarks detected in face landmark list
        top_lip = face_landmarks.get('top_lip') # extract the top coordinate of the lip
        bottom_lip = face_landmarks.get('bottom_lip') # extract the bottom coordinate of the lip
        
        if not top_lip or not bottom_lip: # if top lip coordinate or bottom lip coordinate is not there
            lip_error = True # set lip_error flag to true , meaning the lip is not properly detected
            continue # continue and move to the next lip coordinate
        
        # Determine the bounding box for the lips
        lip_points = np.array(top_lip + bottom_lip) # combines the x, y coordinates that are extracted  into a numpy array
        x, y, w, h = cv2.boundingRect(lip_points) #find the smallest rectangle that covers all the detected coordinate points
        
        # Check if the detected lip region is too large or too small, which might indicate obstruction or misdetection
        if w < 5 or h < 5 or w > 100 or h > 100:
            lip_error = True # if so the lip_error is set to true
            continue # else continue
        
        lip_region = rgb_image[y:y+h, x:x+w] #extract the lip region from the bounding box detected
        
        # Resize and normalize the lip region
        lip_region = cv2.resize(lip_region, lip_size) # resize the lip region with the given size that was initially mentioned
        lip_region = lip_region.astype('float32') / 255 #convert the pixel values to floating point values and normalize them between 0 and 1
        lip_features.append(lip_region.flatten()) # flatten the processed lips to one dimensional array and append it to lip_features

    return np.array(lip_features), lip_error #return the list of lip_features in a numpy array format along with the flag values as true or false


def store_lip_features(name, lip_features):
    conn = sqlite3.connect(db_name) # Connect to the SQLite database
    c = conn.cursor() # Create a cursor to execute the queries
    c.execute('''CREATE TABLE IF NOT EXISTS lip_biometrics (name TEXT, lip_encoding BLOB)''')  # Create a table if it doesn't exist
    for lip_feature in lip_features:
        c.execute("INSERT INTO lip_biometrics (name, lip_encoding) VALUES (?, ?)",
                  (name, lip_feature.tobytes())) # lip features extracted are stored separately along with the name 
    conn.commit() # Commit the transaction
    conn.close() # Close the connection

def load_lip_features():
    conn = sqlite3.connect(db_name) # Connect to the SQLite database
    c = conn.cursor() # Create a cursor to execute the queries
    c.execute("SELECT name, lip_encoding FROM lip_biometrics") # Select the name and lip_encoding from the table
    rows = c.fetchall()  # Fetch all rows
    names = [] # Initialize an empty list for names
    lip_encodings = [] # Initialize an empty list for lip_encodings
    for row in rows:
        name = row[0] # Extract name
        lip_encoding = np.frombuffer(row[1], dtype=np.float32) # Extract encoding and convert to numby array from binary form
        names.append(name) # Append name to the list
        lip_encodings.append(lip_encoding) # Append encoding to the list
    conn.close() # Close the connection
    return names, lip_encodings # Return names and lip_encodings

def verify_lip_identity(input_lip_features, stored_names, stored_lip_encodings):
    min_distance = float('inf') # set the minimum distance between stored and input lip features to infinity initially
    best_match_name = "Unknown" # set the best_match name to "Unknown" initially
    for i, stored_lip in enumerate(stored_lip_encodings): # loop through the store lip encodings
        if input_lip_features.shape == stored_lip.shape: # check if the shape of the input_lip_fetaures and stored features are same
            distance = np.linalg.norm(input_lip_features - stored_lip)  # if so, calculate the distance between them 
            if distance < min_distance: # if calculated distance is less than set minimum distance
                min_distance = distance # update the minimum distance
                best_match_name = stored_names[i] # update the name with the stored name
    return best_match_name # finally return the name with the least distance between the input and the stored lip fetaures

