# import libraries
import cv2
import numpy as np
import sqlite3

# database declaration and image size configuration
iris_database = "iris_database.db" #initialize a database and store it inside a variable
iris_size = (50,50) #mention a iris image size to which the captured image will be resized

#capture image
def capture_image():
    video_capture = cv2.VideoCapture(0) #Opens the webcame
    ret, frame = video_capture.read() #captures a single frame of image from webcam
    video_capture.release() #release the webcam
    return frame #returns the captured image

#convert BGR to RGB
def change_bgr_rgb(image):
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) # convert the image from BGR to RGB
    return rgb_image #return the converted image

#extract the iris features
def extract_iris_features(rgb_image):
    #convert rgb image to grayscale
    gray = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2GRAY)
    #loading pre-trained Haarcascade classifier for eye detection
    eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
    #using detectMultiScale to search for eyes using the pre-trained model
    detect_eyes = eye_cascade.detectMultiScale(gray, 1.3, 5)
    #initialise empty list to store iris features of each eye
    iris_features = []
    #loop over the detected eyes by the detectMultiScale
    for (ex, ey, ew, eh) in detect_eyes:
        eye_region = rgb_image[ey:ey + ey , ex:ex + ew]#extract the eye region from the detected coordinations
        eye_region = cv2.resize(eye_region,iris_size) # resize the eye region image to the mentioned fixed size
        eye_region = eye_region.astype('float32')/255 #normalize the image so that the features are easily scalable and improve ML performance
        iris_features.append(eye_region.flatten()) #convert the image from 2D to 1D array and store in the iris feature list
        return np.array(iris_features) # return the iris features in the form of array 
    
    
#store the features in a SQLite database
def store_features(name, iris_features):
    conn = sqlite3.connect(iris_database)# Connect to the SQLite database
    c = conn.cursor() # Create a cursor to execute the queries
    c.execute('''CREATE TABLE IF NOT EXISTS iris_biometrics (name TEXT, iris_encoding BLOB)''') # Create a table if it doesn't exist
    for iris_feature in iris_features: 
        c.execute("INSERT INTO iris_biometrics (name, iris_encoding) VALUES (?, ?)",
                  (name, iris_feature.tobytes())) # eye features extracted are stored separately along with the name 
    conn.commit() # Commit the transaction
    conn.close() # Close the connection






#load the stored features from the SQLite database
def load_features():
    conn = sqlite3.connect(iris_database) # Connect to the SQLite database
    c = conn.cursor() # Create a cursor to execute the queries
    c.execute("SELECT name, iris_encoding FROM iris_biometrics") # Select the name and iris_encoding from the table
    rows = c.fetchall() # Fetch all rows
    names = [] # Initialize an empty list for names
    iris_encodings = [] # Initialize an empty list for iris_encodings
    for row in rows:
        name = row[0] # Extract name
        iris_encoding = np.frombuffer(row[1], dtype=np.float32) # Extract encoding and convert to numby array from binary form
        names.append(name)  # Append name to the list
        iris_encodings.append(iris_encoding) # Append encoding to the list
    conn.close() # Close the connection
    return names, iris_encodings # Return names and iris_encodings


#verify the stored iris features with the new captured iris features
def verify_iris_features(input_iris_features,stored_names,stored_iris_encodings):
    minimun_dist = float('inf') # set the minimum distance between stored and input iris features to infinity initially
    best_match = "Unknown" # set the best_match name to "Unknown" initially
    for i,stored_iris in enumerate(stored_iris_encodings): # loop through the store iris encodings
        if input_iris_features.shape == stored_iris.shape: # check if the shape of the input_iris_fetaures and stored features are same
            distance = np.linalg.norm(input_iris_features - stored_iris) # if so, calculate the distance between them 
            if distance < minimun_dist: # if calculated distance is less than set minimum distance
                minimun_dist = distance # update the minimum distance
                best_match = stored_names[i] # update the name with the stored name
    return best_match # finally return the name with the least distance between the input and the stored iris fetaures

